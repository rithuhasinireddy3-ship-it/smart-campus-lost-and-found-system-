import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.*;

public class LostAndFoundSystem {

    // ---------------------------------------------------------------
    // Model class
    // ---------------------------------------------------------------
    static class Item {
        private final int id;
        private final String type;        // LOST or FOUND
        private final String name;
        private final String category;
        private final String location;
        private final LocalDate date;
        private final String description;
        private final String reporter;
        private final String contact;
        private String status;            // OPEN or RETURNED
        private String claimedBy;         // "-" until the item is returned

        Item(int id, String type, String name, String category, String location,
             LocalDate date, String description, String reporter, String contact,
             String status, String claimedBy) {
            this.id = id;
            this.type = type;
            this.name = name;
            this.category = category;
            this.location = location;
            this.date = date;
            this.description = description;
            this.reporter = reporter;
            this.contact = contact;
            this.status = status;
            this.claimedBy = claimedBy;
        }

        int getId() { return id; }
        String getType() { return type; }
        String getName() { return name; }
        String getCategory() { return category; }
        String getLocation() { return location; }
        LocalDate getDate() { return date; }
        String getDescription() { return description; }
        String getReporter() { return reporter; }
        String getContact() { return contact; }
        String getStatus() { return status; }
        String getClaimedBy() { return claimedBy; }
        void setStatus(String status) { this.status = status; }
        void setClaimedBy(String claimedBy) { this.claimedBy = claimedBy; }
        boolean isOpen() { return status.equals("OPEN"); }

        String toFileLine() {
            return String.join("|", String.valueOf(id), type, name, category,
                    location, date.toString(), description, reporter, contact,
                    status, claimedBy);
        }

        static Item fromFileLine(String line) {
            String[] p = line.split("\\|", -1);
            if (p.length != 11) return null;
            try {
                return new Item(Integer.parseInt(p[0]), p[1], p[2], p[3], p[4],
                        LocalDate.parse(p[5]), p[6], p[7], p[8], p[9], p[10]);
            } catch (NumberFormatException | DateTimeParseException ex) {
                return null;
            }
        }
    }

    // ---------------------------------------------------------------
    // Data members
    // ---------------------------------------------------------------
    private static final String DATA_DIR = "data";
    private static final String DATA_FILE = "data/items.txt";
    private static final String[] CATEGORIES =
            {"Electronics", "Books", "ID Cards", "Accessories", "Clothing", "Others"};
    private static final int MATCH_LIMIT = 50;
    private static final Scanner in = new Scanner(System.in);
    private static final List<Item> items = new ArrayList<>();

    // ---------------------------------------------------------------
    // Program entry point
    // ---------------------------------------------------------------
    public static void main(String[] args) {
        loadItems();
        int choice;
        do {
            printMenu();
            choice = readInt("Enter your choice: ", 0, 7);
            switch (choice) {
                case 1: reportItem("LOST"); break;
                case 2: reportItem("FOUND"); break;
                case 3: viewItems(); break;
                case 4: searchItems(); break;
                case 5: smartMatch(); break;
                case 6: markReturned(); break;
                case 7: showStatistics(); break;
                case 0:
                    System.out.println("Thank you for using the Smart Campus "
                            + "Lost and Found System.");
                    break;
            }
        } while (choice != 0);
    }

    private static void printMenu() {
        System.out.println();
        System.out.println("========== SMART CAMPUS LOST AND FOUND SYSTEM ==========");
        System.out.println(" 1. Report Lost Item");
        System.out.println(" 2. Report Found Item");
        System.out.println(" 3. View Items");
        System.out.println(" 4. Search Items");
        System.out.println(" 5. Smart Match for a Lost Item");
        System.out.println(" 6. Mark Item as Returned");
        System.out.println(" 7. Statistics Report");
        System.out.println(" 0. Exit");
        System.out.println("========================================================");
    }

    // ---------------------------------------------------------------
    // File handling
    // ---------------------------------------------------------------
    private static void loadItems() {
        File file = new File(DATA_FILE);
        if (!file.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                Item item = Item.fromFileLine(line);
                if (item != null) items.add(item);
            }
        } catch (IOException ex) {
            System.out.println("Could not read data file: " + ex.getMessage());
        }
    }

    private static void saveItems() {
        new File(DATA_DIR).mkdirs();
        try (PrintWriter out = new PrintWriter(new FileWriter(DATA_FILE))) {
            for (Item item : items) {
                out.println(item.toFileLine());
            }
        } catch (IOException ex) {
            System.out.println("Could not save data file: " + ex.getMessage());
        }
    }

    // ---------------------------------------------------------------
    // Input helpers with validation
    // ---------------------------------------------------------------
    private static int readInt(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String line = in.nextLine().trim();
            try {
                int value = Integer.parseInt(line);
                if (value >= min && value <= max) return value;
            } catch (NumberFormatException ignored) { }
            System.out.println("Invalid input. Enter a number between "
                    + min + " and " + max + ".");
        }
    }

    private static String readText(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = in.nextLine().trim();
            if (!line.isEmpty() && !line.contains("|")) return line;
            System.out.println("Field cannot be empty or contain the | character.");
        }
    }

    private static LocalDate readDate(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = in.nextLine().trim();
            try {
                return LocalDate.parse(line);
            } catch (DateTimeParseException ex) {
                System.out.println("Invalid date. Use the format yyyy-MM-dd "
                        + "(for example 2026-10-21).");
            }
        }
    }

    private static String readContact(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = in.nextLine().trim();
            if (line.matches("\\d{10}")) return line;
            System.out.println("Enter a valid 10-digit phone number.");
        }
    }

    private static String chooseCategory() {
        System.out.println("Category:");
        for (int i = 0; i < CATEGORIES.length; i++) {
            System.out.println("  " + (i + 1) + ". " + CATEGORIES[i]);
        }
        int choice = readInt("Choose category (1-" + CATEGORIES.length + "): ",
                1, CATEGORIES.length);
        return CATEGORIES[choice - 1];
    }

    private static Item findById(int id) {
        for (Item item : items) {
            if (item.getId() == id) return item;
        }
        return null;
    }

    private static int nextId() {
        int max = 0;
        for (Item item : items) {
            if (item.getId() > max) max = item.getId();
        }
        return max + 1;
    }

    // ---------------------------------------------------------------
    // Table printing
    // ---------------------------------------------------------------
    private static String cut(String text, int width) {
        return text.length() <= width ? text : text.substring(0, width - 2) + "..";
    }

    private static void printLine() {
        System.out.println("-------------------------------------------"
                + "---------------------------------------");
    }

    private static void printHeader() {
        printLine();
        System.out.printf("%-3s %-5s %-20s %-12s %-14s %-10s %-8s%n",
                "ID", "Type", "Item", "Category", "Location", "Date", "Status");
        printLine();
    }

    private static void printRow(Item item) {
        System.out.printf("%-3d %-5s %-20s %-12s %-14s %-10s %-8s%n",
                item.getId(), item.getType(), cut(item.getName(), 20),
                item.getCategory(), cut(item.getLocation(), 14),
                item.getDate(), item.getStatus());
    }

    // ---------------------------------------------------------------
    // 1 and 2. Report a lost or found item
    // ---------------------------------------------------------------
    private static void reportItem(String type) {
        boolean lost = type.equals("LOST");
        System.out.println();
        System.out.println("--- Report " + (lost ? "Lost" : "Found") + " Item ---");
        String name = readText("Item name: ");
        String category = chooseCategory();
        String location = readText(lost ? "Where was it lost? "
                : "Where was it found? ");
        LocalDate date = readDate("Date (yyyy-MM-dd): ");
        String description = readText("Short description: ");
        String reporter = readText("Your name: ");
        String contact = readContact("Contact number (10 digits): ");

        Item item = new Item(nextId(), type, name, category, location, date,
                description, reporter, contact, "OPEN", "-");
        items.add(item);
        saveItems();
        System.out.println((lost ? "Lost" : "Found")
                + " item reported successfully! ID = " + item.getId());
        showMatches(item);
    }

    // ---------------------------------------------------------------
    // Smart matching
    // ---------------------------------------------------------------
    private static boolean sharesWord(String a, String b) {
        Set<String> words = new HashSet<>();
        for (String w : a.toLowerCase().split("[^a-z0-9]+")) {
            if (w.length() >= 3) words.add(w);
        }
        for (String w : b.toLowerCase().split("[^a-z0-9]+")) {
            if (w.length() >= 3 && words.contains(w)) return true;
        }
        return false;
    }

    private static int matchScore(Item a, Item b) {
        int score = 0;
        if (a.getCategory().equals(b.getCategory())) score += 40;
        if (a.getLocation().equalsIgnoreCase(b.getLocation())) score += 30;
        if (sharesWord(a.getName(), b.getName())) score += 20;
        if (Math.abs(ChronoUnit.DAYS.between(a.getDate(), b.getDate())) <= 3)
            score += 10;
        return score;
    }

    private static void showMatches(Item base) {
        List<Item> matches = new ArrayList<>();
        for (Item other : items) {
            if (!other.getType().equals(base.getType()) && other.isOpen()
                    && matchScore(base, other) >= MATCH_LIMIT) {
                matches.add(other);
            }
        }
        System.out.println();
        if (matches.isEmpty()) {
            System.out.println("No matching reports found yet.");
            return;
        }
        matches.sort((x, y) -> matchScore(base, y) - matchScore(base, x));
        System.out.println("--- Possible Matches (score " + MATCH_LIMIT
                + "% or more) ---");
        printLine();
        System.out.printf("%-3s %-5s %-20s %-14s %-10s %-6s%n",
                "ID", "Type", "Item", "Location", "Date", "Match");
        printLine();
        for (Item m : matches) {
            System.out.printf("%-3d %-5s %-20s %-14s %-10s %3d%%%n",
                    m.getId(), m.getType(), cut(m.getName(), 20),
                    cut(m.getLocation(), 14), m.getDate(), matchScore(base, m));
        }
        System.out.println("Contact " + matches.get(0).getReporter() + " on "
                + matches.get(0).getContact() + " to verify the best match.");
    }

    // ---------------------------------------------------------------
    // 3. View items
    // ---------------------------------------------------------------
    private static void viewItems() {
        System.out.println();
        System.out.println("Show: 1. All  2. Lost only  3. Found only  4. Open only");
        int filter = readInt("Choose filter (1-4): ", 1, 4);
        List<Item> list = new ArrayList<>();
        for (Item item : items) {
            if (filter == 1
                    || (filter == 2 && item.getType().equals("LOST"))
                    || (filter == 3 && item.getType().equals("FOUND"))
                    || (filter == 4 && item.isOpen())) {
                list.add(item);
            }
        }
        System.out.println();
        if (list.isEmpty()) {
            System.out.println("No items found.");
            return;
        }
        System.out.println("--- Items ---");
        printHeader();
        for (Item item : list) {
            printRow(item);
        }
        System.out.println("Total items shown: " + list.size());
    }

    // ---------------------------------------------------------------
    // 4. Search items
    // ---------------------------------------------------------------
    private static void searchItems() {
        System.out.println();
        System.out.print("Enter ID, item name, category, location or keyword: ");
        String key = in.nextLine().trim().toLowerCase();
        if (key.isEmpty()) {
            System.out.println("Please enter a search term.");
            return;
        }
        List<Item> found = new ArrayList<>();
        for (Item item : items) {
            if (String.valueOf(item.getId()).equals(key)
                    || item.getName().toLowerCase().contains(key)
                    || item.getCategory().toLowerCase().contains(key)
                    || item.getLocation().toLowerCase().contains(key)
                    || item.getDescription().toLowerCase().contains(key)) {
                found.add(item);
            }
        }
        if (found.isEmpty()) {
            System.out.println("No matching items found.");
            return;
        }
        System.out.println("--- Search Results ---");
        printHeader();
        for (Item item : found) {
            printRow(item);
        }
        System.out.println(found.size() + " record(s) found.");
    }

    // ---------------------------------------------------------------
    // 5. Smart match for a lost item
    // ---------------------------------------------------------------
    private static void smartMatch() {
        System.out.println();
        int id = readInt("Enter ID of the lost item: ", 1, Integer.MAX_VALUE);
        Item item = findById(id);
        if (item == null) {
            System.out.println("Item with ID " + id + " not found.");
            return;
        }
        if (!item.getType().equals("LOST")) {
            System.out.println("Item " + id + " is a FOUND report. "
                    + "Smart match works for LOST items.");
            return;
        }
        if (!item.isOpen()) {
            System.out.println("Item " + id + " is already marked as "
                    + item.getStatus() + ".");
            return;
        }
        System.out.println("Searching matches for: " + item.getName()
                + " (" + item.getCategory() + ", " + item.getLocation() + ", "
                + item.getDate() + ")");
        showMatches(item);
    }

    // ---------------------------------------------------------------
    // 6. Mark item as returned
    // ---------------------------------------------------------------
    private static void markReturned() {
        System.out.println();
        int id = readInt("Enter ID of the item to mark as returned: ",
                1, Integer.MAX_VALUE);
        Item item = findById(id);
        if (item == null) {
            System.out.println("Item with ID " + id + " not found.");
            return;
        }
        if (!item.isOpen()) {
            System.out.println("Item " + id + " is already marked as "
                    + item.getStatus() + ".");
            return;
        }
        String owner = readText("Returned to / claimed by (name): ");
        System.out.print("Mark \"" + item.getName() + "\" as returned to "
                + owner + "? (y/n): ");
        String answer = in.nextLine().trim().toLowerCase();
        if (!answer.equals("y")) {
            System.out.println("Action cancelled.");
            return;
        }
        item.setStatus("RETURNED");
        item.setClaimedBy(owner);

        int related = readInt("Related report ID to close as well (0 for none): ",
                0, Integer.MAX_VALUE);
        if (related != 0) {
            Item other = findById(related);
            if (other == null || !other.isOpen()
                    || other.getType().equals(item.getType())) {
                System.out.println("Report " + related + " cannot be closed "
                        + "with this item.");
            } else {
                other.setStatus("RETURNED");
                other.setClaimedBy(owner);
                System.out.println("Related report " + related + " closed too.");
            }
        }
        saveItems();
        System.out.println("Item marked as RETURNED.");
    }

    // ---------------------------------------------------------------
    // 7. Statistics report
    // ---------------------------------------------------------------
    private static void showStatistics() {
        System.out.println();
        if (items.isEmpty()) {
            System.out.println("No reports found.");
            return;
        }
        int lost = 0, found = 0, open = 0, returned = 0;
        Map<String, Integer> categories = new TreeMap<>();
        Map<String, Integer> places = new TreeMap<>();
        for (Item item : items) {
            if (item.getType().equals("LOST")) lost++; else found++;
            if (item.isOpen()) open++; else returned++;
            categories.merge(item.getCategory(), 1, Integer::sum);
            places.merge(item.getLocation(), 1, Integer::sum);
        }
        String busiest = null;
        for (Map.Entry<String, Integer> e : places.entrySet()) {
            if (busiest == null || e.getValue() > places.get(busiest)) {
                busiest = e.getKey();
            }
        }
        System.out.println("--- Statistics Report ---");
        System.out.println("Total reports    : " + items.size());
        System.out.println("Lost reports     : " + lost);
        System.out.println("Found reports    : " + found);
        System.out.println("Open             : " + open);
        System.out.println("Returned         : " + returned);
        System.out.printf("Recovery rate    : %.1f%%%n",
                returned * 100.0 / items.size());
        System.out.println("By category      : " + categories);
        System.out.println("Busiest location : " + busiest
                + " (" + places.get(busiest) + " report(s))");
    }
}
