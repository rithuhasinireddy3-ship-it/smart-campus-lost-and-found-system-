# Smart Campus Lost and Found System

A Java console application to report, search, match and return lost and found items on a campus.

## Requirements
- Java JDK 8 or above

## Run
    javac LostAndFoundSystem.java
    java LostAndFoundSystem

## Files
- LostAndFoundSystem.java : complete source code
- data/items.txt          : sample reports (delete the file for a fresh start;
                            the program recreates it when the first report is saved)

## Menu
1 Report Lost Item | 2 Report Found Item | 3 View Items | 4 Search Items
5 Smart Match | 6 Mark Item as Returned | 7 Statistics Report | 0 Exit
